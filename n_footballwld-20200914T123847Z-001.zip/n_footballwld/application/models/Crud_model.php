<?php

class Crud_model extends CI_Model {

	
	public function getAllData()
	{
        $query=$this->db->get('s_table');
        
        if($query){
            return $query->result();
        }
    }
    public function insertDatta($data){
        $query=$this->db->insert('s_table',$data);
        if($query){
            return true;
        }
        else{
            return false;
        }
    }

    public function deleteItem($si){
        $this->db->where('si',$si);
        $query=$this->db->delete('s_table');
        if($query){
            return true;
        }else{
            return false;
        }
    }
    

    public function getsingleData($si){
        $this->db->where('si',$si);
        $query=$this->db->get('s_table');
        if($query){
            return $query->row();
        }
    }

    public function updateDatta($data,$si){
        $this->db->where('si',$si);
        $query=$this->db->update('s_table',$data);
        if($query){
            return true;
        }
        else{
            return false;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
</head>
<body>
<div class="jumbotron" >
     <h2 align="center" style="text-transform: uppercase">Update Data</h2>
   </div>
   <div class="container">
        <form method="post" action="<?php echo base_url(); ?>crud/update/<?php echo $singleData->si; ?>">
        <div class="form-group">
                <label for="si">Si</label>
                <input type="number" name="si" class="form-control" id="exampleInputSi" aria-describedby="siHelp" value="<?php echo $singleData->si; ?>">
                
            </div>
            <div class="form-group">
                <label for="exampleInputText">Team</label>
                <input type="text"  name="team" class="form-control" id="exampleInputText"value="<?php echo $singleData->team; ?>" aria-describedby="textHelp">
                
            </div>
            <div class="form-group">
                <label for="exampleInputText">Vs</label>
                <input type="text" name="vs" class="form-control" value="<?php echo $singleData->vs; ?>" id="exampleInputText">
            </div>

            <div class="form-group">
                <label for="exampleInputText">Team</label>
                <input type="text" name="teamm" class="form-control"value="<?php echo $singleData->teamm; ?>"  id="exampleInputText" aria-describedby="textHelp">
                
            </div>
            <div class="form-group">
                <label for="exampleInputText">Time</label>
                <input type="text"  name="time" class="form-control" value="<?php echo $singleData->time; ?>"  id="exampleInputText" aria-describedby="textHelp">
                
            </div>
            <div class="form-group">
                <label for="exampleInputText">Venue</label>
                <input type="text"  name="venue" class="form-control" value="<?php echo $singleData->venue; ?>"  id="exampleInputText" aria-describedby="textHelp">
                
            </div>
           
        <button type="submit" name="edit" value="update" class="btn btn-primary">Edit</button>
        </form>
   </div>
  
   <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
   <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 </body>
</html>
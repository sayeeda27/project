<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller {

	
	public function index()
	{
		$this->load->model('crud_model');
       $data['schdl_data']=$this->crud_model->getAllData();
		$this->load->view('crud_view',$data);
	}

	public function insertData(){

		$this->form_validation->set_rules('si','team serial','trim|required');
		$this->form_validation->set_rules('team','team name','trim|required');
		$this->form_validation->set_rules('vs','vs','trim|required');
		$this->form_validation->set_rules('teamm','another team name','trim|required');
		$this->form_validation->set_rules('time','play time','trim|required');
		$this->form_validation->set_rules('venue','venue name','trim|required');

		if($this->form_validation->run()==false){

			$data_error=[
				'error'=>validation_errors()
			];

			$this->session->set_flashdata($data_error);
		}
		else{
			$this->load->model('crud_model');
			$result=$this->crud_model->insertDatta([
				'si'=>$this->input->post('si'),
				'team'=>$this->input->post('team'),
				'vs'=>$this->input->post('vs'),
				'teamm'=>$this->input->post('teamm'),
				'time'=>$this->input->post('time'),
				'venue'=>$this->input->post('venue')

			]);
			if($result){
				$this->session->set_flashdata('inserted','Data has been added!!');
			}
		}
		redirect('crud');
	}


	public function deleteData($si){
		$this->load->model('crud_model');
		$result=$this->crud_model->deleteItem($si);
		if($result==true){
			$this->session->set_flashdata('deleted','Data has been deleted!!');
		}
		redirect('crud');
	}


	public function editData($si){
		$this->load->model('crud_model');
		$data['singleData']=$this->crud_model->getsingleData($si);
		$this->load->view('edit_view',$data);
	}

	public function update($si){
		$this->form_validation->set_rules('si','team serial','trim|required');
		$this->form_validation->set_rules('team','team name','trim|required');
		$this->form_validation->set_rules('vs','vs','trim|required');
		$this->form_validation->set_rules('teamm','another team name','trim|required');
		$this->form_validation->set_rules('time','play time','trim|required');
		$this->form_validation->set_rules('venue','venue name','trim|required');

		if($this->form_validation->run()==false){

			$data_error=[
				'error'=>validation_errors()
			];

			$this->session->set_flashdata($data_error);
		}
		else{
			$this->load->model('crud_model');
			$result=$this->crud_model->updateDatta([
				'si'=>$this->input->post('si'),
				'team'=>$this->input->post('team'),
				'vs'=>$this->input->post('vs'),
				'teamm'=>$this->input->post('teamm'),
				'time'=>$this->input->post('time'),
				'venue'=>$this->input->post('venue')

			], $si);
			if($result){
				$this->session->set_flashdata('updated','Data has been updated!!');
			}
		}
		redirect('crud');
	}
}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Football World</title>
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style.css">
</head>
<body>

    <div class="crud_bg">
  <div class="jumbotron" >
     <div class="crud_head">
       <h2 align="center" style="text-transform: uppercase">Schedule</h2>
      </div>
   </div>
   <div class="container">
   <div class="clear-fix">
   <h2 style="float:left" >Team name</h2>
    <a class="btn btn-primary" href="#" style="float:right"data-toggle="modal" data-target="#exampleModalCenter">Insert</a>
   </div>
     <table class="table table-stripped table-hover">
       <thead>
       <tr>
          <th>Si</th>
          <th>Team</th>
          <th>Vs</th>
          <th>Team</th>
          <th>Time</th>
          <th>Venue</th>
          <th colspan="2">Action</th>
      </tr>
       </thead>
       <tbody>
       <?php foreach($schdl_data as $s_data): ?>
        <tr>
          <td> <?php  echo  $s_data->si; ?> </td>
          <td><?php  echo  $s_data->team; ?></td>
          <td><?php  echo  $s_data->vs; ?></td>
          <td><?php  echo  $s_data->teamm; ?></td>
          <td><?php  echo  $s_data->time; ?></td>
          <td><?php  echo  $s_data->venue; ?></td>
          <td>
          <a  class="btn btn-success" href="<?php echo base_url(); ?>crud/editData/<?php echo $s_data->si; ?>">Edit </a>
          <a  class="btn btn-danger" href="<?php echo base_url(); ?>crud/deleteData/<?php echo $s_data->si; ?>">Delete </a>
          </td>
          
        </tr>
       <?php endforeach;  ?>
       </tbody>
     </table>
     <?php if($this->session->flashdata('error')): ?>
  <div align="center" style="color:#FFF" class="bg-danger">
   <?php echo $this->session->flashdata('error'); ?>
  </div>
   <?php endif; ?>


   <?php if($this->session->flashdata('inserted')): ?>
  <div align="center" style="color:#FFF" class="bg-success">
   <?php echo $this->session->flashdata('inserted'); ?>
  </div>
   <?php endif; ?>

   <?php if($this->session->flashdata('deleted')): ?>
  <div align="center" style="color:#FFF" class="bg-danger">
   <?php echo $this->session->flashdata('deleted'); ?>
  </div>
   <?php endif; ?>

   <?php if($this->session->flashdata('updated')): ?>
  <div align="center" style="color:#FFF" class="bg-success">
   <?php echo $this->session->flashdata('updated'); ?>
  </div>
   <?php endif; ?>

   </div>


  </div>
    


<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
    <form method="post" action="<?php echo base_url();?>crud/insertData">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Insert Team Schedule</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div class="form-group">
       <label for="si">Si</label>
       <input type="number" name="si" placeholder="enter  si number " class="form-control">
       </div>

       <div class="form-group">
       <label for="team">Team</label>
       <input type="text" name="team" placeholder="enter team" class="form-control">
       </div>

       <div class="form-group">
       <label for="vs">Vs</label>
       <input type="text" name="vs" placeholder="enter vs" class="form-control">
       </div>

       <div class="form-group">
       <label for="teamm">Team</label>
       <input type="text" name="teamm" placeholder="enter team name" class="form-control">
       </div>

       <div class="form-group">
       <label for="time">Time</label>
       <input type="text" name="time" placeholder="enter time" class="form-control">
       </div>

       <div class="form-group">
       <label for="venue">Venue</label>
       <input type="text" name="venue" placeholder="enter venue name" class="form-control">
       </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" name ="insert" value="Add Data" class="btn btn-info">
      </div>
      </form>
    </div>
  </div>
</div>
  
   <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>